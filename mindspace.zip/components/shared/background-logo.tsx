import Image from "next/image"

export function BackgroundLogo() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0 flex items-center justify-center opacity-[0.03]">
      <div className="relative h-[80vh] w-[80vh] max-w-full">
        <Image
          src="/images/mindshark-logo.png"
          alt="Mindshark Logo Background"
          fill
          className="object-contain"
          priority
        />
      </div>
    </div>
  )
}
