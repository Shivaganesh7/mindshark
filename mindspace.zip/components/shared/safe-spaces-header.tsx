"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ChevronLeft, LogOut } from "lucide-react"
import Image from "next/image"

interface SafeSpacesHeaderProps {
  showBackButton?: boolean
  isAdmin?: boolean
}

export function SafeSpacesHeader({ showBackButton = false, isAdmin = false }: SafeSpacesHeaderProps) {
  const router = useRouter()

  const handleBack = () => {
    if (isAdmin) {
      router.push("/admin/dashboard")
    } else {
      router.push("/student/home")
    }
  }

  const handleLogout = () => {
    router.push("/")
  }

  return (
    <header className="sticky top-0 z-10 flex h-16 items-center justify-between border-b border-gray-200 bg-white px-4 shadow-sm">
      <div className="flex items-center gap-2">
        {showBackButton && (
          <Button variant="ghost" size="icon" onClick={handleBack} className="h-8 w-8 rounded-full">
            <ChevronLeft className="h-5 w-5" />
            <span className="sr-only">Back</span>
          </Button>
        )}
        <div className="flex items-center gap-2">
          <div className="relative h-8 w-8 overflow-hidden rounded-full">
            <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
          </div>
          <span className="font-semibold text-gray-900">
            SafeSpaces {isAdmin && <span className="text-blue-600">Admin</span>}
          </span>
        </div>
      </div>
      <Button
        variant="ghost"
        size="icon"
        onClick={handleLogout}
        className="h-8 w-8 rounded-full text-gray-500"
        title="Logout"
      >
        <LogOut className="h-5 w-5" />
        <span className="sr-only">Logout</span>
      </Button>
    </header>
  )
}
