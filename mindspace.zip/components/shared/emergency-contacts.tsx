"use client"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Card, CardContent } from "@/components/ui/card"
import { Phone, AlertTriangle } from "lucide-react"

export function EmergencyContacts() {
  const emergencyContacts = [
    { name: "Campus Security", phone: "555-123-4567", available: "24/7" },
    { name: "Health Center", phone: "555-123-8900", available: "8AM - 8PM" },
    { name: "Counseling Services", phone: "555-123-5678", available: "9AM - 5PM" },
    { name: "Janigala Vignesh Kumar", phone: "9390644324", role: "SafeSpaces Admin" },
  ]

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2 bg-red-50 text-red-600 hover:bg-red-100">
          <AlertTriangle className="h-4 w-4" />
          Emergency Contacts
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <AlertTriangle className="h-5 w-5" />
            Emergency Contacts
          </DialogTitle>
          <DialogDescription>Important contacts for urgent situations</DialogDescription>
        </DialogHeader>

        <div className="space-y-3 pt-2">
          {emergencyContacts.map((contact, index) => (
            <Card key={index} className="overflow-hidden border-l-4 border-l-red-500">
              <CardContent className="p-3">
                <div className="mb-1 font-medium">{contact.name}</div>
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-red-500" />
                  <a href={`tel:${contact.phone}`} className="text-blue-600 hover:underline">
                    {contact.phone}
                  </a>
                </div>
                <div className="mt-1 text-xs text-gray-500">
                  {contact.available ? `Available: ${contact.available}` : contact.role}
                </div>
              </CardContent>
            </Card>
          ))}

          <div className="rounded-lg bg-red-50 p-3 text-center">
            <div className="mb-1 font-medium text-red-700">For immediate danger</div>
            <div className="flex items-center justify-center gap-2">
              <Phone className="h-5 w-5 text-red-600" />
              <a href="tel:911" className="text-xl font-bold text-red-600 hover:underline">
                911
              </a>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
