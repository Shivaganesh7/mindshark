"use client"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Card, CardContent } from "@/components/ui/card"
import { Phone, Mail } from "lucide-react"
import Image from "next/image"

export function ContactModal() {
  const contacts = [
    { name: "Janigala Vignesh Kumar", phone: "9390644324", email: "vignesh@mindshark.edu" },
    { name: "Konam Pranavi", phone: "8919679724", email: "pranavi@mindshark.edu" },
    { name: "Gouroju Shiva Ganesh", phone: "9177719826", email: "shiva@mindshark.edu" },
    { name: "Mamidi Indhu", phone: "9676985276", email: "indhu@mindshark.edu" },
  ]

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="link" className="text-gray-400 hover:text-blue-400">
          Contact
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-center gap-2 text-2xl">
            <div className="relative h-10 w-10">
              <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
            </div>
            Contact Our Team
          </DialogTitle>
          <DialogDescription className="text-center">
            Reach out to our team members for any questions or assistance
          </DialogDescription>
        </DialogHeader>

        <div className="mt-6 grid gap-4 md:grid-cols-2">
          {contacts.map((contact, index) => (
            <Card key={index} className="overflow-hidden">
              <CardContent className="p-4">
                <h3 className="mb-2 font-semibold">{contact.name}</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-gray-500" />
                    <a href={`tel:${contact.phone}`} className="text-blue-600 hover:underline">
                      {contact.phone}
                    </a>
                  </div>
                  <div className="flex items-center gap-2">
                    <Mail className="h-4 w-4 text-gray-500" />
                    <a href={`mailto:${contact.email}`} className="text-blue-600 hover:underline">
                      {contact.email}
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-4 rounded-lg bg-blue-50 p-4">
          <h3 className="mb-2 font-semibold text-blue-800">Emergency Contact</h3>
          <p className="mb-2 text-sm text-gray-700">For urgent matters requiring immediate attention:</p>
          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-red-500" />
            <a href="tel:911" className="text-red-600 hover:underline">
              Emergency Hotline: 911
            </a>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
