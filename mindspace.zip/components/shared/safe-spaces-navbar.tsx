"use client"

import { cn } from "@/lib/utils"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Home, FileText, ClipboardList, BarChart2, Settings } from "lucide-react"

interface SafeSpacesNavbarProps {
  activeTab: "home" | "submissions" | "reports" | "analytics" | "settings" | "none"
  role: "student" | "admin"
}

export function SafeSpacesNavbar({ activeTab, role }: SafeSpacesNavbarProps) {
  const router = useRouter()

  const studentTabs = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      path: "/student/home",
    },
    {
      id: "submissions",
      label: "My Reports",
      icon: FileText,
      path: "/student/my-submissions",
    },
  ]

  const adminTabs = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      path: "/admin/dashboard",
    },
    {
      id: "reports",
      label: "Reports",
      icon: ClipboardList,
      path: "/admin/reports",
    },
    {
      id: "analytics",
      label: "Analytics",
      icon: BarChart2,
      path: "/admin/analytics",
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings,
      path: "/admin/settings",
    },
  ]

  const tabs = role === "student" ? studentTabs : adminTabs

  return (
    <nav className="sticky bottom-0 z-10 flex h-16 items-center justify-around border-t border-gray-200 bg-white px-2 shadow-sm">
      {tabs.map((tab) => (
        <Button
          key={tab.id}
          variant="ghost"
          className={cn(
            "flex h-full flex-1 flex-col items-center justify-center rounded-none text-xs",
            activeTab === tab.id ? "text-teal-600" : "text-gray-500 hover:text-gray-900",
          )}
          onClick={() => router.push(tab.path)}
        >
          <tab.icon className="mb-1 h-5 w-5" />
          {tab.label}
        </Button>
      ))}
    </nav>
  )
}
