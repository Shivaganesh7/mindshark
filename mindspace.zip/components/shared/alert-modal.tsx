"use client"

import { cn } from "@/lib/utils"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { CheckCircle, AlertCircle, Info } from "lucide-react"
import type { ReactNode } from "react"

interface AlertModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  message: string
  type: "success" | "error" | "info"
  customContent?: ReactNode
}

export function AlertModal({ isOpen, onClose, title, message, type, customContent }: AlertModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="rounded-xl sm:max-w-md">
        <DialogHeader className="flex flex-col items-center text-center">
          <div
            className={cn(
              "mb-4 flex h-12 w-12 items-center justify-center rounded-full",
              type === "success" ? "bg-green-100" : type === "error" ? "bg-red-100" : "bg-blue-100",
            )}
          >
            {type === "success" ? (
              <CheckCircle className="h-6 w-6 text-green-600" />
            ) : type === "error" ? (
              <AlertCircle className="h-6 w-6 text-red-600" />
            ) : (
              <Info className="h-6 w-6 text-blue-600" />
            )}
          </div>
          <DialogTitle className="text-xl">{title}</DialogTitle>
          <DialogDescription className="text-center text-gray-600">{message}</DialogDescription>
        </DialogHeader>

        {customContent}

        {!customContent && (
          <DialogFooter className="flex justify-center">
            <Button
              onClick={onClose}
              className={cn(
                "rounded-xl px-8",
                type === "success"
                  ? "bg-teal-600 hover:bg-teal-700"
                  : type === "error"
                    ? "bg-red-600 hover:bg-red-700"
                    : "bg-blue-600 hover:bg-blue-700",
              )}
            >
              OK
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  )
}
