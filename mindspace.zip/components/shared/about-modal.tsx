"use client"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Code, CheckCircle, Shield, MessageCircle, BarChart2 } from "lucide-react"
import Image from "next/image"

export function AboutModal() {
  const contacts = [
    { name: "Janigala Vignesh Kumar", phone: "9390644324", email: "vignesh@mindshark.edu" },
    { name: "Konam Pranavi", phone: "8919679724", email: "pranavi@mindshark.edu" },
    { name: "Gouroju Shiva Ganesh", phone: "9177719826", email: "shiva@mindshark.edu" },
    { name: "Mamidi Indhu", phone: "9676985276", email: "indhu@mindshark.edu" },
  ]

  const technologies = [
    "Next.js 14 (App Router)",
    "React 18",
    "TypeScript",
    "Tailwind CSS",
    "shadcn/ui Components",
    "Recharts for data visualization",
    "Framer Motion for animations",
    "Web Audio API",
  ]

  const features = [
    {
      title: "Anonymous Reporting",
      description: "Submit reports without revealing your identity, ensuring your privacy and safety.",
      icon: Shield,
    },
    {
      title: "Real-time Alerts",
      description: "Administrators receive instant notifications for urgent reports requiring immediate attention.",
      icon: MessageCircle,
    },
    {
      title: "Comprehensive Analytics",
      description: "Track patterns and trends to identify recurring issues and improve campus safety.",
      icon: BarChart2,
    },
  ]

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" className="text-sm">
          About
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] max-w-3xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-center gap-2 text-2xl">
            <div className="relative h-10 w-10">
              <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
            </div>
            About SafeSpaces
          </DialogTitle>
          <DialogDescription className="text-center">
            A secure platform for anonymous reporting and issue resolution
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="about" className="mt-4">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="about">About</TabsTrigger>
            <TabsTrigger value="features">Features</TabsTrigger>
          </TabsList>

          <TabsContent value="about" className="space-y-4 pt-4">
            <div className="flex justify-center">
              <div className="relative h-32 w-32">
                <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
              </div>
            </div>

            <div className="text-center">
              <h3 className="text-lg font-bold">SafeSpaces by Mindshark</h3>
              <p className="text-gray-600">
                SafeSpaces is a comprehensive platform designed to create safer environments for students and staff by
                providing an anonymous reporting system with efficient resolution tracking.
              </p>
            </div>

            <div className="rounded-lg bg-blue-50 p-4">
              <h3 className="mb-2 font-semibold text-blue-800">About SafeSpaces</h3>
              <p className="text-sm text-gray-700">
                SafeSpaces was developed to address the growing need for secure and anonymous reporting systems in
                educational institutions. Our platform enables students to report issues without fear of retaliation,
                while providing administrators with powerful tools to address and resolve these concerns efficiently.
              </p>
              <p className="mt-2 text-sm text-gray-700">
                With real-time notifications, comprehensive analytics, and a user-friendly interface, SafeSpaces helps
                create a safer and more supportive environment for everyone.
              </p>
            </div>

            <div>
              <h3 className="mb-2 font-semibold">Technologies Used</h3>
              <div className="grid grid-cols-2 gap-2">
                {technologies.map((tech, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Code className="h-4 w-4 text-blue-600" />
                    <span className="text-sm">{tech}</span>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="mb-2 font-semibold">Developed By</h3>
              <p className="text-sm text-gray-600">
                SafeSpaces was developed by the Mindshark team, a group of students passionate about creating safer
                educational environments through technology.
              </p>
            </div>
          </TabsContent>

          <TabsContent value="features" className="pt-4">
            <div className="mb-4 rounded-lg bg-blue-50 p-4">
              <h3 className="mb-2 font-semibold text-blue-800">Key Features</h3>
              <p className="text-sm text-gray-700">
                SafeSpaces offers a comprehensive set of features designed to facilitate secure reporting and efficient
                resolution of issues. Our platform prioritizes user privacy while providing powerful tools for
                administrators.
              </p>
            </div>

            <div className="grid gap-4 md:grid-cols-1">
              {features.map((feature, index) => (
                <Card key={index} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="mb-2 flex items-center gap-2">
                      <feature.icon className="h-5 w-5 text-blue-600" />
                      <h3 className="font-semibold">{feature.title}</h3>
                    </div>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="mt-4 rounded-lg bg-blue-50 p-4">
              <h3 className="mb-2 font-semibold text-blue-800">Additional Features</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>Mobile-responsive design for access on any device</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>Secure data encryption for all sensitive information</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>Interactive chatbot for immediate assistance</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-blue-600" />
                  <span>Emergency contact access for urgent situations</span>
                </li>
              </ul>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
