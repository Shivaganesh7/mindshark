"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MessageCircle, Send, X } from "lucide-react"

// Predefined responses for the chatbot
const CHATBOT_RESPONSES: Record<string, string> = {
  default: "Hello! How can I help you today with SafeSpaces?",
  help: "I can help you navigate the dashboard, submit reports, or learn about SafeSpaces features. What would you like to know?",
  report:
    "To submit a report, go to the 'Submit Report' section. You can choose to remain anonymous and provide details about the incident.",
  contact:
    "You can find contact information in the About section. Our team is available to assist you with any questions or concerns.",
  features:
    "SafeSpaces offers anonymous reporting, quick resolution tracking, and a secure communication channel for all users.",
  about:
    "SafeSpaces is developed by Mindshark, a team dedicated to creating safer environments for students and staff.",
}

export function Chatbot() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<{ text: string; isUser: boolean }[]>([
    { text: CHATBOT_RESPONSES.default, isUser: false },
  ])
  const [input, setInput] = useState("")

  const handleSend = () => {
    if (!input.trim()) return

    // Add user message
    setMessages((prev) => [...prev, { text: input, isUser: true }])

    // Generate response based on keywords
    let response = CHATBOT_RESPONSES.default
    const lowercaseInput = input.toLowerCase()

    if (lowercaseInput.includes("help")) {
      response = CHATBOT_RESPONSES.help
    } else if (lowercaseInput.includes("report") || lowercaseInput.includes("submit")) {
      response = CHATBOT_RESPONSES.report
    } else if (lowercaseInput.includes("contact")) {
      response = CHATBOT_RESPONSES.contact
    } else if (lowercaseInput.includes("feature")) {
      response = CHATBOT_RESPONSES.features
    } else if (lowercaseInput.includes("about")) {
      response = CHATBOT_RESPONSES.about
    }

    // Add bot response after a short delay
    setTimeout(() => {
      setMessages((prev) => [...prev, { text: response, isUser: false }])
    }, 500)

    setInput("")
  }

  return (
    <>
      {/* Chatbot toggle button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-20 right-4 z-50 flex h-12 w-12 items-center justify-center rounded-full bg-blue-600 p-0 shadow-lg hover:bg-blue-700 md:bottom-6 md:right-6"
      >
        {isOpen ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </Button>

      {/* Chatbot window */}
      {isOpen && (
        <Card className="fixed bottom-36 right-4 z-50 w-80 overflow-hidden rounded-xl border-none shadow-xl md:bottom-20 md:right-6 md:w-96">
          <CardHeader className="bg-blue-600 px-4 py-3">
            <CardTitle className="flex items-center gap-2 text-white">
              <MessageCircle className="h-5 w-5" />
              SafeSpaces Assistant
            </CardTitle>
          </CardHeader>
          <CardContent className="h-80 overflow-y-auto p-3">
            <div className="flex flex-col gap-3">
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`rounded-lg p-3 ${
                    message.isUser
                      ? "ml-auto max-w-[80%] bg-blue-600 text-white"
                      : "mr-auto max-w-[80%] bg-gray-100 text-gray-800"
                  }`}
                >
                  {message.text}
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter className="border-t p-3">
            <form
              className="flex w-full gap-2"
              onSubmit={(e) => {
                e.preventDefault()
                handleSend()
              }}
            >
              <Input
                placeholder="Type your message..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1"
              />
              <Button type="submit" size="icon" className="h-10 w-10 rounded-full bg-blue-600 p-0 hover:bg-blue-700">
                <Send className="h-4 w-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      )}
    </>
  )
}
