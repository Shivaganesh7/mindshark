"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { SafeSpacesHeader } from "@/components/shared/safe-spaces-header"
import { SafeSpacesNavbar } from "@/components/shared/safe-spaces-navbar"
import { BackgroundLogo } from "@/components/shared/background-logo"
import { Chatbot } from "@/components/shared/chatbot"
import { EmergencyContacts } from "@/components/shared/emergency-contacts"
import { AboutModal } from "@/components/shared/about-modal"
import { PenLine, FileText, ShieldCheck, Bell, Info } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { useEffect, useState } from "react"
import Image from "next/image"

// Sample notifications for demonstration
const notifications = [
  { id: 1, message: "Your recent report has been reviewed", isRead: false },
  { id: 2, message: "A new safety tip has been published", isRead: true },
]

export default function StudentHomePage() {
  const router = useRouter()
  const { toast } = useToast()
  const [unreadNotifications, setUnreadNotifications] = useState(0)

  useEffect(() => {
    // Count unread notifications
    const unreadCount = notifications.filter((n) => !n.isRead).length
    setUnreadNotifications(unreadCount)

    // Welcome toast on component mount
    toast({
      title: "Welcome back!",
      description: "You're now logged in to SafeSpaces.",
    })
  }, [toast])

  const handleNotificationClick = () => {
    toast({
      title: "Notifications",
      description: `You have ${unreadNotifications} unread notifications.`,
    })
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-teal-50 to-blue-50">
      {/* Background Logo */}
      <BackgroundLogo />

      <SafeSpacesHeader />

      <main className="relative z-10 flex-1 p-4">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-12 w-12 overflow-hidden rounded-full border-2 border-blue-100 bg-white p-1 shadow-sm">
              <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
            </div>
            <div className="space-y-0">
              <h1 className="text-2xl font-bold text-gray-900">Hi, Anonymous!</h1>
              <p className="text-gray-600">What would you like to do today?</p>
            </div>
          </div>
          <Button variant="outline" size="icon" className="relative rounded-full" onClick={handleNotificationClick}>
            <Bell className="h-5 w-5" />
            {unreadNotifications > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs text-white">
                {unreadNotifications}
              </span>
            )}
          </Button>
        </div>

        {/* Info Bar with About and Emergency Contacts */}
        <Card className="mb-6 border-none bg-white/80 shadow-sm backdrop-blur-sm">
          <CardContent className="flex items-center justify-between p-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Info className="h-4 w-4 text-blue-600" />
              <span>SafeSpaces by Mindshark - Secure Anonymous Reporting Platform</span>
            </div>
            <div className="flex items-center gap-4">
              <EmergencyContacts />
              <AboutModal />
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4">
          <Button
            onClick={() => router.push("/student/submit-report")}
            className="flex h-auto items-center justify-start gap-3 rounded-xl bg-blue-600 p-4 text-left text-white hover:bg-blue-700"
          >
            <div className="rounded-full bg-blue-500 p-2">
              <PenLine className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-semibold">Submit a Report</div>
              <div className="text-sm opacity-90">Report an issue anonymously</div>
            </div>
          </Button>

          <Button
            onClick={() => router.push("/student/my-submissions")}
            className="flex h-auto items-center justify-start gap-3 rounded-xl bg-blue-600 p-4 text-left text-white hover:bg-blue-700"
          >
            <div className="rounded-full bg-blue-500 p-2">
              <FileText className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-semibold">My Submissions</div>
              <div className="text-sm opacity-90">View your previous reports</div>
            </div>
          </Button>
        </div>

        <Card className="mt-6 rounded-xl border-none bg-white/80 shadow-md">
          <CardContent className="flex items-center gap-3 p-4">
            <div className="rounded-full bg-blue-100 p-2 text-blue-600">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <p className="text-sm text-gray-600">
              <span className="font-medium">Safety Tip:</span> All reports are anonymous by default. Your identity is
              protected.
            </p>
          </CardContent>
        </Card>

        {/* Recent Activity Section */}
        <div className="mt-6">
          <h2 className="mb-3 text-lg font-semibold text-gray-900">Recent Activity</h2>
          {notifications.map((notification) => (
            <Card key={notification.id} className="mb-3 rounded-xl border-none shadow-sm">
              <CardContent className="flex items-center gap-3 p-3">
                <div className={`h-2 w-2 rounded-full ${notification.isRead ? "bg-gray-300" : "bg-blue-500"}`}></div>
                <p className="text-sm text-gray-700">{notification.message}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>

      <SafeSpacesNavbar activeTab="home" role="student" />

      {/* Chatbot */}
      <Chatbot />
    </div>
  )
}
