"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { SafeSpacesHeader } from "@/components/shared/safe-spaces-header"
import { SafeSpacesNavbar } from "@/components/shared/safe-spaces-navbar"
import { AlertModal } from "@/components/shared/alert-modal"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, Camera, X, ImageIcon, Film } from "lucide-react"

export default function SubmitReportPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [description, setDescription] = useState("")
  const [location, setLocation] = useState("")
  const [category, setCategory] = useState("")
  const [anonymous, setAnonymous] = useState(true)
  const [showSuccessModal, setShowSuccessModal] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<{ description?: string }>({})

  // Media upload states
  const [images, setImages] = useState<string[]>([])
  const [videos, setVideos] = useState<string[]>([])
  const [isCapturing, setIsCapturing] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoInputRef = useRef<HTMLInputElement>(null)
  const cameraRef = useRef<HTMLVideoElement>(null)

  const validateForm = () => {
    const newErrors: { description?: string } = {}

    if (!description.trim()) {
      newErrors.description = "Please provide a description of the issue"
    } else if (description.trim().length < 10) {
      newErrors.description = "Description must be at least 10 characters"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) {
      toast({
        title: "Validation Error",
        description: "Please fix the errors in the form.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    // Simulate API call
    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))
      setShowSuccessModal(true)
    } catch (error) {
      toast({
        title: "Submission failed",
        description: "There was an error submitting your report. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleModalClose = () => {
    setShowSuccessModal(false)
    router.push("/student/home")
  }

  // Handle image upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newImages = Array.from(e.target.files).map((file) => URL.createObjectURL(file))
      setImages([...images, ...newImages])
      toast({
        title: "Images uploaded",
        description: `${e.target.files.length} image(s) added to your report.`,
      })
    }
  }

  // Handle video upload
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newVideos = Array.from(e.target.files).map((file) => URL.createObjectURL(file))
      setVideos([...videos, ...newVideos])
      toast({
        title: "Videos uploaded",
        description: `${e.target.files.length} video(s) added to your report.`,
      })
    }
  }

  // Handle camera capture
  const startCamera = async () => {
    setIsCapturing(true)
    try {
      if (cameraRef.current) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true })
        cameraRef.current.srcObject = stream
      }
    } catch (err) {
      toast({
        title: "Camera Error",
        description: "Could not access your camera. Please check permissions.",
        variant: "destructive",
      })
      setIsCapturing(false)
    }
  }

  const captureImage = () => {
    if (cameraRef.current) {
      const canvas = document.createElement("canvas")
      canvas.width = cameraRef.current.videoWidth
      canvas.height = cameraRef.current.videoHeight
      canvas.getContext("2d")?.drawImage(cameraRef.current, 0, 0, canvas.width, canvas.height)
      const imageUrl = canvas.toDataURL("image/jpeg")
      setImages([...images, imageUrl])
      stopCamera()
      toast({
        title: "Image captured",
        description: "Photo added to your report.",
      })
    }
  }

  const stopCamera = () => {
    if (cameraRef.current && cameraRef.current.srcObject) {
      const stream = cameraRef.current.srcObject as MediaStream
      const tracks = stream.getTracks()
      tracks.forEach((track) => track.stop())
      cameraRef.current.srcObject = null
      setIsCapturing(false)
    }
  }

  // Remove media
  const removeImage = (index: number) => {
    const newImages = [...images]
    newImages.splice(index, 1)
    setImages(newImages)
  }

  const removeVideo = (index: number) => {
    const newVideos = [...videos]
    newVideos.splice(index, 1)
    setVideos(newVideos)
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-teal-50 to-blue-50">
      <SafeSpacesHeader showBackButton />

      <main className="flex-1 p-4">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Submit a Report</h1>
          <p className="text-gray-600">Your report will be reviewed by our team</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="description" className="flex items-center">
              Describe the issue <span className="ml-1 text-red-500">*</span>
            </Label>
            <Textarea
              id="description"
              placeholder="Please provide details about the issue..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className={`min-h-[150px] rounded-xl ${errors.description ? "border-red-500" : ""}`}
              aria-invalid={errors.description ? "true" : "false"}
            />
            {errors.description && <p className="text-xs text-red-500">{errors.description}</p>}
            <p className="text-xs text-gray-500">{description.length} / 500 characters (minimum 10)</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Location (Optional)</Label>
            <Select value={location} onValueChange={setLocation}>
              <SelectTrigger id="location" className="rounded-xl">
                <SelectValue placeholder="Select location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="library">Library</SelectItem>
                <SelectItem value="cafeteria">Cafeteria</SelectItem>
                <SelectItem value="dormitory">Dormitory</SelectItem>
                <SelectItem value="classroom">Classroom</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">Category (Optional)</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger id="category" className="rounded-xl">
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="hygiene">Hygiene</SelectItem>
                <SelectItem value="harassment">Harassment</SelectItem>
                <SelectItem value="safety">Safety</SelectItem>
                <SelectItem value="facilities">Facilities</SelectItem>
                <SelectItem value="general">General</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Media Upload Section */}
          <div className="space-y-4">
            <Label>Add Media Evidence (Optional)</Label>

            <div className="flex flex-wrap gap-2">
              <Button
                type="button"
                variant="outline"
                className="flex items-center gap-2"
                onClick={() => fileInputRef.current?.click()}
              >
                <ImageIcon className="h-4 w-4" />
                Upload Images
              </Button>

              <Button
                type="button"
                variant="outline"
                className="flex items-center gap-2"
                onClick={() => videoInputRef.current?.click()}
              >
                <Film className="h-4 w-4" />
                Upload Videos
              </Button>

              <Button type="button" variant="outline" className="flex items-center gap-2" onClick={startCamera}>
                <Camera className="h-4 w-4" />
                Take Photo
              </Button>
            </div>

            <input
              type="file"
              ref={fileInputRef}
              className="hidden"
              accept="image/*"
              multiple
              onChange={handleImageUpload}
            />

            <input
              type="file"
              ref={videoInputRef}
              className="hidden"
              accept="video/*"
              multiple
              onChange={handleVideoUpload}
            />

            {/* Camera Capture UI */}
            {isCapturing && (
              <div className="relative mt-4 rounded-lg border bg-white p-4 shadow-sm">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-2 z-10 rounded-full"
                  onClick={stopCamera}
                >
                  <X className="h-4 w-4" />
                </Button>
                <div className="flex flex-col items-center">
                  <video
                    ref={cameraRef}
                    autoPlay
                    playsInline
                    className="mb-4 h-64 rounded-lg bg-black object-cover"
                  ></video>
                  <Button type="button" onClick={captureImage} className="bg-teal-600 hover:bg-teal-700">
                    <Camera className="mr-2 h-4 w-4" />
                    Capture Photo
                  </Button>
                </div>
              </div>
            )}

            {/* Preview uploaded images */}
            {images.length > 0 && (
              <div className="space-y-2">
                <Label>Uploaded Images ({images.length})</Label>
                <div className="grid grid-cols-3 gap-2">
                  {images.map((image, index) => (
                    <div key={`img-${index}`} className="relative h-24 overflow-hidden rounded-lg">
                      <img
                        src={image || "/placeholder.svg"}
                        alt={`Uploaded ${index + 1}`}
                        className="h-full w-full object-cover"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute right-1 top-1 h-6 w-6 rounded-full"
                        onClick={() => removeImage(index)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Preview uploaded videos */}
            {videos.length > 0 && (
              <div className="space-y-2">
                <Label>Uploaded Videos ({videos.length})</Label>
                <div className="grid grid-cols-2 gap-2">
                  {videos.map((video, index) => (
                    <div key={`vid-${index}`} className="relative rounded-lg">
                      <video src={video} controls className="h-32 w-full rounded-lg bg-black object-cover"></video>
                      <Button
                        type="button"
                        variant="destructive"
                        size="icon"
                        className="absolute right-1 top-1 h-6 w-6 rounded-full"
                        onClick={() => removeVideo(index)}
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <Label htmlFor="anonymous">Submit Anonymously</Label>
              <p className="text-xs text-gray-500">Your identity will not be revealed</p>
            </div>
            <Switch id="anonymous" checked={anonymous} onCheckedChange={setAnonymous} />
          </div>

          <Button
            type="submit"
            className="w-full rounded-xl bg-teal-600 py-6 text-lg font-medium text-white hover:bg-teal-700"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Submitting...
              </>
            ) : (
              "Submit Report"
            )}
          </Button>
        </form>
      </main>

      <SafeSpacesNavbar activeTab="none" role="student" />

      <AlertModal
        isOpen={showSuccessModal}
        onClose={handleModalClose}
        title="Report Submitted!"
        message="Your report has been sent anonymously. We appreciate your contribution."
        type="success"
      />
    </div>
  )
}
