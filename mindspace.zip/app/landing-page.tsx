"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Shield, MessageCircle, Users, ChevronRight, CheckCircle, ArrowRight, BellRing } from "lucide-react"
import { motion } from "framer-motion"
import Image from "next/image"
import { ContactModal } from "@/components/shared/contact-modal"

export default function LandingPage() {
  const router = useRouter()
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.5,
      },
    },
  }

  const stats = [
    { value: "100+", label: "Schools Using SafeSpaces", icon: Users },
    { value: "10k+", label: "Reports Resolved", icon: CheckCircle },
    { value: "98%", label: "User Satisfaction", icon: MessageCircle },
  ]

  const features = [
    {
      title: "Anonymous Reporting",
      description:
        "Submit reports without revealing your identity, ensuring your privacy and safety in sensitive situations.",
      icon: Shield,
      color: "bg-blue-600",
    },
    {
      title: "Real-time Alerts",
      description:
        "Administrators receive instant notifications with extended buzzer alerts for urgent reports requiring immediate attention.",
      icon: BellRing,
      color: "bg-blue-600",
    },
    {
      title: "Interactive Chatbot",
      description: "Get immediate assistance and guidance through our AI-powered chatbot available 24/7 for all users.",
      icon: MessageCircle,
      color: "bg-blue-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 via-blue-50 to-white">
      {/* Navigation */}
      <nav className="fixed top-0 z-10 w-full bg-white/80 px-4 py-4 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="relative h-10 w-10">
              <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-gray-900">SafeSpaces</span>
              <span className="text-xs text-blue-600">by Mindshark</span>
            </div>
          </div>
          <div className="hidden space-x-6 md:flex">
            <a href="#features" className="text-gray-600 hover:text-blue-600">
              Features
            </a>
          </div>
          <Button
            onClick={() => router.push("/login")}
            className="rounded-full bg-blue-600 px-6 py-2 text-white hover:bg-blue-700"
          >
            Log In
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <motion.section
        initial="hidden"
        animate={isLoaded ? "visible" : "hidden"}
        variants={containerVariants}
        className="flex min-h-screen flex-col items-center justify-center px-4 pt-20 text-center"
      >
        <motion.div
          variants={itemVariants}
          className="mb-2 inline-block rounded-full bg-blue-100 px-4 py-1 text-sm font-medium text-blue-800"
        >
          Introducing SafeSpaces
        </motion.div>
        <motion.h1
          variants={itemVariants}
          className="mb-6 max-w-4xl text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl"
        >
          Report Issues. <span className="text-blue-600">Stay Safe.</span>
        </motion.h1>
        <motion.p variants={itemVariants} className="mb-4 max-w-2xl text-xl text-gray-600">
          A secure platform for students to anonymously report issues and for administrators to address them
          efficiently.
        </motion.p>
        <motion.p variants={itemVariants} className="mb-8 text-lg font-medium text-blue-600">
          by Mindshark
        </motion.p>
        <motion.div variants={itemVariants} className="flex flex-wrap justify-center gap-4">
          <Button
            onClick={() => router.push("/login")}
            className="rounded-full bg-blue-600 px-8 py-6 text-lg font-medium text-white hover:bg-blue-700"
          >
            Get Started <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              const featuresSection = document.getElementById("features")
              featuresSection?.scrollIntoView({ behavior: "smooth" })
            }}
            className="rounded-full border-gray-300 px-8 py-6 text-lg font-medium text-gray-700 hover:bg-gray-100"
          >
            Learn More
          </Button>
        </motion.div>

        {/* Hero Image - Replaced with Mindshark logo and illustration */}
        <motion.div
          variants={itemVariants}
          className="relative mt-16 w-full max-w-5xl overflow-hidden rounded-2xl shadow-2xl"
        >
          <div className="aspect-[16/9] bg-gradient-to-r from-blue-600 to-blue-800 p-1">
            <div className="flex h-full w-full items-center justify-center rounded-xl bg-white p-4">
              <div className="flex h-full w-full flex-col items-center justify-center rounded-lg bg-blue-50 p-4 shadow-inner">
                <div className="relative h-48 w-48 md:h-64 md:w-64">
                  <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
                </div>
                <div className="mt-6 text-center">
                  <h2 className="text-2xl font-bold text-blue-800">SafeSpaces Platform</h2>
                  <p className="mt-2 text-blue-600">Secure. Anonymous. Effective.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="absolute bottom-4 right-4 rounded-full bg-white p-3 shadow-lg">
            <Shield className="h-6 w-6 text-blue-600" />
          </div>
        </motion.div>
      </motion.section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {stats.map((stat, index) => (
              <Card key={index} className="overflow-hidden border-none shadow-lg">
                <CardContent className="flex items-center gap-4 p-6">
                  <div className="rounded-full bg-blue-100 p-3">
                    <stat.icon className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-gray-900">{stat.value}</div>
                    <div className="text-sm text-gray-500">{stat.label}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold text-gray-900 sm:text-4xl">Key Features</h2>
            <p className="mx-auto max-w-2xl text-lg text-gray-600">
              SafeSpaces provides powerful tools for both students and administrators to create a safer environment.
            </p>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="overflow-hidden border-none shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
              >
                <CardContent className="p-0">
                  <div className={`h-2 w-full ${feature.color}`}></div>
                  <div className="p-6">
                    <div className={`mb-4 inline-flex rounded-full ${feature.color} bg-opacity-20 p-3`}>
                      <feature.icon className={`h-6 w-6 ${feature.color.replace("bg-", "text-")}`} />
                    </div>
                    <h3 className="mb-2 text-xl font-bold text-gray-900">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-16 text-center">
            <h2 className="mb-4 text-3xl font-bold text-gray-900 sm:text-4xl">How It Works</h2>
            <p className="mx-auto max-w-2xl text-lg text-gray-600">
              SafeSpaces makes it easy to report and resolve issues in just a few simple steps.
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-1/2 top-0 h-full w-1 -translate-x-1/2 bg-blue-200 md:block"></div>
            <div className="space-y-12">
              {[
                {
                  step: "01",
                  title: "Create an Account",
                  description: "Sign up with your school email to get started with SafeSpaces.",
                },
                {
                  step: "02",
                  title: "Submit a Report",
                  description: "Describe the issue you've encountered and submit it anonymously.",
                },
                {
                  step: "03",
                  title: "Admin Review",
                  description: "Administrators review and categorize your report for appropriate action.",
                },
                {
                  step: "04",
                  title: "Resolution",
                  description: "The issue is addressed and resolved, with updates provided to you.",
                },
              ].map((item, index) => (
                <div key={index} className="relative">
                  <div className="absolute left-1/2 top-4 flex h-10 w-10 -translate-x-1/2 items-center justify-center rounded-full bg-blue-600 text-white">
                    {item.step}
                  </div>
                  <div
                    className={`ml-0 md:ml-${index % 2 === 0 ? "0" : "auto"} w-full md:w-5/12 ${index % 2 === 0 ? "md:pr-12" : "md:pl-12"}`}
                  >
                    <Card className="border-none shadow-lg">
                      <CardContent className="p-6">
                        <h3 className="mb-2 text-xl font-bold text-gray-900">{item.title}</h3>
                        <p className="text-gray-600">{item.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 py-20 text-white">
        <div className="mx-auto max-w-7xl px-4 text-center">
          <h2 className="mb-4 text-3xl font-bold sm:text-4xl">Ready to create a safer environment?</h2>
          <p className="mx-auto mb-8 max-w-2xl text-lg text-blue-100">
            Join thousands of students and administrators who are making their schools safer with SafeSpaces.
          </p>
          <Button
            onClick={() => router.push("/login")}
            className="rounded-full bg-white px-8 py-6 text-lg font-medium text-blue-600 hover:bg-blue-50"
          >
            Get Started Now <ChevronRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 py-12 text-gray-400">
        <div className="mx-auto max-w-7xl px-4">
          <div className="mb-8 flex items-center justify-center gap-2">
            <div className="relative h-10 w-10">
              <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-white">SafeSpaces</span>
              <span className="text-sm text-blue-400">by Mindshark</span>
            </div>
          </div>
          <div className="mb-8 flex flex-wrap justify-center gap-8">
            <Button variant="link" className="text-gray-400 hover:text-blue-400">
              About
            </Button>
            <Button variant="link" className="text-gray-400 hover:text-blue-400">
              Features
            </Button>
            <Button variant="link" className="text-gray-400 hover:text-blue-400">
              Privacy Policy
            </Button>
            <Button variant="link" className="text-gray-400 hover:text-blue-400">
              Terms of Service
            </Button>
            <ContactModal />
          </div>
          <div className="text-center text-sm">
            <p>&copy; {new Date().getFullYear()} SafeSpaces by Mindshark. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
