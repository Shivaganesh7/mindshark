"use client"

import type React from "react"

import { useState } from "react"
import { SafeSpacesHeader } from "@/components/shared/safe-spaces-header"
import { SafeSpacesNavbar } from "@/components/shared/safe-spaces-navbar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { AlertModal } from "@/components/shared/alert-modal"

export default function AdminSettingsPage() {
  const [emailAlerts, setEmailAlerts] = useState(true)
  const [showSuccessModal, setShowSuccessModal] = useState(false)

  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault()
    setShowSuccessModal(true)
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-teal-50 to-blue-50">
      <SafeSpacesHeader showBackButton isAdmin />

      <main className="flex-1 p-4">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600">Manage your account and preferences</p>
        </div>

        <div className="space-y-6">
          <Card className="rounded-xl border-none shadow-md">
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
              <CardDescription>Update your account password</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSavePassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="current-password">Current Password</Label>
                  <Input id="current-password" type="password" className="rounded-lg" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-password">New Password</Label>
                  <Input id="new-password" type="password" className="rounded-lg" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="confirm-password">Confirm New Password</Label>
                  <Input id="confirm-password" type="password" className="rounded-lg" />
                </div>
                <Button type="submit" className="w-full rounded-lg bg-teal-600 hover:bg-teal-700">
                  Update Password
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card className="rounded-xl border-none shadow-md">
            <CardHeader>
              <CardTitle>Auto-Response Messages</CardTitle>
              <CardDescription>Set automatic responses for new reports</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="auto-response">Default Auto-Response</Label>
                <Textarea
                  id="auto-response"
                  className="min-h-[100px] rounded-lg"
                  defaultValue="Thank you for your report. Our team has received it and will review it shortly. Your safety is our priority."
                />
              </div>
              <Button className="w-full rounded-lg bg-teal-600 hover:bg-teal-700">Save Message</Button>
            </CardContent>
          </Card>

          <Card className="rounded-xl border-none shadow-md">
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Manage your notification preferences</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="email-alerts">Email Alerts</Label>
                  <p className="text-sm text-gray-500">Receive email notifications for new reports</p>
                </div>
                <Switch id="email-alerts" checked={emailAlerts} onCheckedChange={setEmailAlerts} />
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <SafeSpacesNavbar activeTab="settings" role="admin" />

      <AlertModal
        isOpen={showSuccessModal}
        onClose={() => setShowSuccessModal(false)}
        title="Password Updated"
        message="Your password has been successfully updated."
        type="success"
      />
    </div>
  )
}
