"use client"

import { cn } from "@/lib/utils"

import { useState, useEffect } from "react"
import { SafeSpacesHeader } from "@/components/shared/safe-spaces-header"
import { SafeSpacesNavbar } from "@/components/shared/safe-spaces-navbar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { formatDistanceToNow } from "date-fns"
import { Filter, Search, X, CheckCircle, AlertCircle } from "lucide-react"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { AlertModal } from "@/components/shared/alert-modal"

// Sample data for demonstration
const reports = [
  {
    id: 1,
    description: "Broken light fixture in the east wing hallway",
    category: "Facilities",
    urgency: "Low",
    status: "Resolved",
    createdAt: new Date(2023, 4, 15),
  },
  {
    id: 2,
    description: "Inappropriate behavior from a student in the cafeteria",
    category: "Harassment",
    urgency: "High",
    status: "Under Review",
    createdAt: new Date(2023, 5, 2),
  },
  {
    id: 3,
    description: "Water leak in the bathroom on the second floor",
    category: "Hygiene",
    urgency: "Medium",
    status: "Submitted",
    createdAt: new Date(),
  },
  {
    id: 4,
    description: "Bullying incident reported in the playground",
    category: "Harassment",
    urgency: "High",
    status: "Submitted",
    createdAt: new Date(),
  },
  {
    id: 5,
    description: "Graffiti on the wall near the entrance",
    category: "Facilities",
    urgency: "Low",
    status: "Under Review",
    createdAt: new Date(2023, 5, 10),
  },
]

export default function AdminReportsPage() {
  const { toast } = useToast()
  const [categoryFilter, setCategoryFilter] = useState("all")
  const [statusFilter, setStatusFilter] = useState("all")
  const [urgencyFilter, setUrgencyFilter] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [showFilters, setShowFilters] = useState(false)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedReport, setSelectedReport] = useState<number | null>(null)
  const [showReportModal, setShowReportModal] = useState(false)

  useEffect(() => {
    // Simulate loading data
    setTimeout(() => {
      setIsLoading(false)
    }, 1000)
  }, [])

  const filteredReports = reports.filter((report) => {
    const matchesCategory = categoryFilter === "all" || report.category === categoryFilter
    const matchesStatus = statusFilter === "all" || report.status === statusFilter
    const matchesUrgency = urgencyFilter === "all" || report.urgency === urgencyFilter
    const matchesSearch =
      searchQuery === "" ||
      report.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      report.category.toLowerCase().includes(searchQuery.toLowerCase())

    return matchesCategory && matchesStatus && matchesUrgency && matchesSearch
  })

  const resetFilters = () => {
    setCategoryFilter("all")
    setStatusFilter("all")
    setUrgencyFilter("all")
    setSearchQuery("")
    toast({
      title: "Filters Reset",
      description: "All filters have been cleared.",
    })
  }

  const handleViewReport = (id: number) => {
    setSelectedReport(id)
    setShowReportModal(true)
  }

  const handleUpdateStatus = (id: number, newStatus: string) => {
    // In a real app, this would update the status in the database
    toast({
      title: "Status Updated",
      description: `Report #${id} has been marked as ${newStatus}.`,
      variant: "default",
    })
    setShowReportModal(false)
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-teal-50 to-blue-50">
      <SafeSpacesHeader showBackButton isAdmin />

      <main className="flex-1 p-4">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">All Reports</h1>
            <p className="text-gray-600">{filteredReports.length} reports found</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-1 rounded-lg border-gray-300"
          >
            <Filter className="h-4 w-4" />
            {showFilters ? "Hide Filters" : "Show Filters"}
          </Button>
        </div>

        {/* Search Bar */}
        <div className="mb-4 relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <Input
            placeholder="Search reports..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-10 rounded-xl"
          />
          {searchQuery && (
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-2 top-1/2 h-6 w-6 -translate-y-1/2 rounded-full p-0"
              onClick={() => setSearchQuery("")}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {showFilters && (
          <Card className="mb-4 rounded-xl border-none shadow-sm">
            <CardContent className="grid grid-cols-3 gap-2 p-3">
              <div>
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="Hygiene">Hygiene</SelectItem>
                    <SelectItem value="Harassment">Harassment</SelectItem>
                    <SelectItem value="Facilities">Facilities</SelectItem>
                    <SelectItem value="Safety">Safety</SelectItem>
                    <SelectItem value="General">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="Submitted">Submitted</SelectItem>
                    <SelectItem value="Under Review">Under Review</SelectItem>
                    <SelectItem value="Resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Select value={urgencyFilter} onValueChange={setUrgencyFilter}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="Urgency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Urgencies</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <div className="flex justify-end px-3 pb-3">
              <Button variant="outline" size="sm" onClick={resetFilters} className="text-xs">
                Reset Filters
              </Button>
            </div>
          </Card>
        )}

        <div className="space-y-4">
          {isLoading ? (
            // Loading skeleton
            Array.from({ length: 3 }).map((_, index) => (
              <Card key={index} className="overflow-hidden rounded-xl border-none shadow-md animate-pulse">
                <CardContent className="p-0">
                  <div className="border-b border-gray-100 bg-white p-4">
                    <div className="mb-2 flex flex-wrap items-center gap-2">
                      <div className="h-6 w-20 rounded-full bg-gray-200"></div>
                      <div className="h-6 w-24 rounded-full bg-gray-200"></div>
                      <div className="ml-auto h-4 w-16 rounded bg-gray-200"></div>
                    </div>
                    <div className="h-4 w-full rounded bg-gray-200"></div>
                  </div>
                  <div className="flex items-center justify-between bg-gray-50 px-4 py-2">
                    <div className="h-4 w-32 rounded bg-gray-200"></div>
                    <div className="h-4 w-20 rounded bg-gray-200"></div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredReports.length > 0 ? (
            filteredReports.map((report) => (
              <Card key={report.id} className="overflow-hidden rounded-xl border-none shadow-md">
                <CardContent className="p-0">
                  <div className="border-b border-gray-100 bg-white p-4">
                    <div className="mb-2 flex flex-wrap items-center gap-2">
                      <Badge
                        className={cn(
                          "rounded-full px-3 py-1 text-xs font-medium",
                          report.status === "Resolved"
                            ? "bg-green-100 text-green-800"
                            : report.status === "Under Review"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-blue-100 text-blue-800",
                        )}
                      >
                        {report.status}
                      </Badge>
                      <Badge
                        className={cn(
                          "rounded-full px-3 py-1 text-xs font-medium",
                          report.urgency === "High"
                            ? "bg-red-100 text-red-800"
                            : report.urgency === "Medium"
                              ? "bg-orange-100 text-orange-800"
                              : "bg-gray-100 text-gray-800",
                        )}
                      >
                        {report.urgency} Urgency
                      </Badge>
                      <span className="ml-auto text-xs text-gray-500">
                        {formatDistanceToNow(report.createdAt, {
                          addSuffix: true,
                        })}
                      </span>
                    </div>
                    <p className="text-sm text-gray-700">{report.description}</p>
                  </div>
                  <div className="flex items-center justify-between bg-gray-50 px-4 py-2">
                    <span className="text-xs font-medium text-gray-500">Category: {report.category}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs font-medium text-teal-600 hover:text-teal-700"
                      onClick={() => handleViewReport(report.id)}
                    >
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center rounded-xl bg-white p-8 text-center shadow">
              <div className="mb-4 rounded-full bg-gray-100 p-3">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="text-gray-400"
                >
                  <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                  <polyline points="14 2 14 8 20 8" />
                  <line x1="16" y1="13" x2="8" y2="13" />
                  <line x1="16" y1="17" x2="8" y2="17" />
                  <polyline points="10 9 9 9 8 9" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900">No reports found</h3>
              <p className="mt-1 text-sm text-gray-500">Try adjusting your filters</p>
              {(categoryFilter !== "all" ||
                statusFilter !== "all" ||
                urgencyFilter !== "all" ||
                searchQuery !== "") && (
                <Button variant="outline" size="sm" onClick={resetFilters} className="mt-4">
                  Reset Filters
                </Button>
              )}
            </div>
          )}
        </div>
      </main>

      <SafeSpacesNavbar activeTab="reports" role="admin" />

      {/* Report Detail Modal */}
      {selectedReport && (
        <AlertModal
          isOpen={showReportModal}
          onClose={() => setShowReportModal(false)}
          title={`Report #${selectedReport}`}
          message={reports.find((r) => r.id === selectedReport)?.description || ""}
          type="info"
          customContent={
            <div className="mt-4 space-y-4">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="font-medium">Category:</div>
                <div>{reports.find((r) => r.id === selectedReport)?.category}</div>
                <div className="font-medium">Urgency:</div>
                <div>{reports.find((r) => r.id === selectedReport)?.urgency}</div>
                <div className="font-medium">Status:</div>
                <div>{reports.find((r) => r.id === selectedReport)?.status}</div>
                <div className="font-medium">Submitted:</div>
                <div>
                  {formatDistanceToNow(reports.find((r) => r.id === selectedReport)?.createdAt || new Date(), {
                    addSuffix: true,
                  })}
                </div>
              </div>

              <div className="flex justify-center space-x-2 pt-2">
                <Button
                  variant="outline"
                  className="flex items-center gap-1"
                  onClick={() => handleUpdateStatus(selectedReport, "Under Review")}
                >
                  <AlertCircle className="h-4 w-4" />
                  Mark as Under Review
                </Button>
                <Button
                  className="flex items-center gap-1 bg-green-600 hover:bg-green-700"
                  onClick={() => handleUpdateStatus(selectedReport, "Resolved")}
                >
                  <CheckCircle className="h-4 w-4" />
                  Mark as Resolved
                </Button>
              </div>
            </div>
          }
        />
      )}
    </div>
  )
}
