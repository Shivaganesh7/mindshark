"use client"

import { useRouter } from "next/navigation"
import { useEffect, useState, useRef } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { SafeSpacesHeader } from "@/components/shared/safe-spaces-header"
import { SafeSpacesNavbar } from "@/components/shared/safe-spaces-navbar"
import { BackgroundLogo } from "@/components/shared/background-logo"
import { Chatbot } from "@/components/shared/chatbot"
import { AboutModal } from "@/components/shared/about-modal"
import {
  ClipboardList,
  BarChart2,
  Settings,
  AlertTriangle,
  TrendingUp,
  Clock,
  BellRing,
  Volume2,
  VolumeX,
  Info,
} from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts"
import { Switch } from "@/components/ui/switch"

// Sample data for demonstration
const categoryData = [
  { name: "Hygiene", value: 15, color: "#0ea5e9" },
  { name: "Harassment", value: 30, color: "#f43f5e" },
  { name: "Safety", value: 20, color: "#f59e0b" },
  { name: "Facilities", value: 25, color: "#10b981" },
  { name: "General", value: 10, color: "#6366f1" },
]

// Sample urgent reports for demonstration
const urgentReports = [
  {
    id: 101,
    description: "Student reported harassment in the cafeteria",
    category: "Harassment",
    time: "5 minutes ago",
  },
  { id: 102, description: "Broken glass in the main hallway", category: "Safety", time: "15 minutes ago" },
  { id: 103, description: "Threatening behavior from a student", category: "Harassment", time: "30 minutes ago" },
]

export default function AdminDashboardPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [timeRange, setTimeRange] = useState("week")
  const [isLoading, setIsLoading] = useState(true)
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [newUrgentReport, setNewUrgentReport] = useState(false)
  const [stats, setStats] = useState({
    total: 0,
    unresolved: 0,
    urgent: 0,
    trend: 0,
  })

  // Audio context reference
  const audioContextRef = useRef<AudioContext | null>(null)
  const oscillatorRef = useRef<OscillatorNode | null>(null)
  const gainNodeRef = useRef<GainNode | null>(null)

  // Function to play a buzzer sound using Web Audio API for 3-5 seconds
  const playBuzzer = () => {
    try {
      // Check if we're in a browser environment with AudioContext support
      if (typeof window !== "undefined" && window.AudioContext) {
        // Stop any existing sound
        if (oscillatorRef.current) {
          oscillatorRef.current.stop()
          oscillatorRef.current = null
        }

        // Create new audio context if needed
        if (!audioContextRef.current) {
          audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)()
        }

        const audioContext = audioContextRef.current
        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()

        oscillatorRef.current = oscillator
        gainNodeRef.current = gainNode

        // Configure oscillator for buzzer sound
        oscillator.type = "square" // Square wave for buzzer sound
        oscillator.frequency.value = 440 // A4 note

        // Connect nodes
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)

        // Set volume
        gainNode.gain.value = 0.1

        // Create buzzer pattern
        const buzzDuration = 4000 // 4 seconds total
        const pulseInterval = 200 // 200ms on/off

        // Start the oscillator
        oscillator.start()

        // Create pulsing effect
        let isOn = true
        const pulseTimer = setInterval(() => {
          if (gainNodeRef.current) {
            gainNodeRef.current.gain.value = isOn ? 0.1 : 0.0
            isOn = !isOn
          }
        }, pulseInterval)

        // Stop the oscillator and clear interval after buzzDuration
        setTimeout(() => {
          if (oscillatorRef.current) {
            oscillatorRef.current.stop()
            oscillatorRef.current = null
          }
          clearInterval(pulseTimer)
        }, buzzDuration)

        return true
      }
      return false
    } catch (error) {
      console.error("Error playing buzzer:", error)
      return false
    }
  }

  // Function to show a browser notification as fallback
  const showNotification = () => {
    try {
      // Check if the browser supports notifications
      if ("Notification" in window) {
        // Check if permission is already granted
        if (Notification.permission === "granted") {
          new Notification("New Urgent Report!", {
            body: "A high urgency report requires your immediate attention.",
            icon: "/images/mindshark-logo.png",
          })
        }
        // Otherwise, request permission
        else if (Notification.permission !== "denied") {
          Notification.requestPermission().then((permission) => {
            if (permission === "granted") {
              new Notification("New Urgent Report!", {
                body: "A high urgency report requires your immediate attention.",
                icon: "/images/mindshark-logo.png",
              })
            }
          })
        }
      }
    } catch (error) {
      console.error("Error showing notification:", error)
    }
  }

  useEffect(() => {
    // Simulate loading data
    const loadData = async () => {
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setStats({
        total: 24,
        unresolved: 8,
        urgent: 3,
        trend: 12,
      })
      setIsLoading(false)

      // Welcome toast
      toast({
        title: "Welcome, Admin",
        description: "You have 3 urgent reports that need your attention.",
      })
    }

    loadData()

    // Simulate receiving a new urgent report after 5 seconds
    const urgentReportTimer = setTimeout(() => {
      setNewUrgentReport(true)

      // Play alert sound if enabled
      if (soundEnabled) {
        const soundPlayed = playBuzzer()

        // If sound failed, try to show a notification
        if (!soundPlayed) {
          showNotification()
        }
      }

      toast({
        title: "⚠️ New Urgent Report!",
        description: "A high urgency report requires your immediate attention.",
        variant: "destructive",
      })
    }, 5000)

    return () => {
      clearTimeout(urgentReportTimer)
      // Clean up audio resources
      if (oscillatorRef.current) {
        oscillatorRef.current.stop()
        oscillatorRef.current = null
      }
    }
  }, [toast, soundEnabled])

  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value)
    setIsLoading(true)

    // Simulate loading new data
    setTimeout(() => {
      // Different stats based on time range
      if (value === "today") {
        setStats({
          total: 5,
          unresolved: 3,
          urgent: 1,
          trend: 2,
        })
      } else if (value === "week") {
        setStats({
          total: 24,
          unresolved: 8,
          urgent: 3,
          trend: 12,
        })
      } else if (value === "month") {
        setStats({
          total: 87,
          unresolved: 15,
          urgent: 7,
          trend: 32,
        })
      }

      setIsLoading(false)

      toast({
        title: "Dashboard Updated",
        description: `Showing data for ${value === "today" ? "today" : value === "week" ? "this week" : "this month"}.`,
      })
    }, 800)
  }

  const toggleSound = () => {
    setSoundEnabled(!soundEnabled)
    toast({
      title: soundEnabled ? "Alert sounds disabled" : "Alert sounds enabled",
      description: soundEnabled
        ? "You will no longer hear sounds for urgent reports."
        : "You will now hear sounds for urgent reports.",
    })
  }

  const playTestSound = () => {
    if (soundEnabled) {
      const soundPlayed = playBuzzer()
      if (!soundPlayed) {
        toast({
          title: "Sound Error",
          description: "Could not play alert sound. Browser audio may be restricted.",
          variant: "destructive",
        })

        // Try to show a notification instead
        showNotification()
      }
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-blue-50 to-blue-50">
      {/* Background Logo */}
      <BackgroundLogo />

      {/* Header with updated logo */}
      <SafeSpacesHeader isAdmin />

      <main className="relative z-10 flex-1 p-4">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative h-12 w-12 overflow-hidden rounded-full border-2 border-blue-100 bg-white p-1 shadow-sm">
              <Image src="/images/mindshark-logo.png" alt="Mindshark Logo" fill className="object-contain" />
            </div>
            <div className="space-y-0">
              <h1 className="text-2xl font-bold text-gray-900">Welcome, Admin</h1>
              <p className="text-gray-600">Dashboard Overview</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 rounded-lg border bg-white px-3 py-1">
              {soundEnabled ? (
                <Volume2 className="h-4 w-4 text-blue-600" onClick={playTestSound} style={{ cursor: "pointer" }} />
              ) : (
                <VolumeX className="h-4 w-4 text-gray-400" />
              )}
              <span className="text-xs">Alert Sound</span>
              <Switch checked={soundEnabled} onCheckedChange={toggleSound} className="ml-1" />
            </div>
            <Select value={timeRange} onValueChange={handleTimeRangeChange}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Select time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Info Bar with About */}
        <Card className="mb-6 border-none bg-white/80 shadow-sm backdrop-blur-sm">
          <CardContent className="flex items-center justify-between p-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Info className="h-4 w-4 text-blue-600" />
              <span>SafeSpaces by Mindshark - Secure Anonymous Reporting Platform</span>
            </div>
            <div className="flex items-center gap-4">
              <AboutModal />
            </div>
          </CardContent>
        </Card>

        <div className="mb-6 grid grid-cols-2 gap-4">
          <Card className={`rounded-xl border-none bg-white shadow-md ${isLoading ? "animate-pulse" : ""}`}>
            <CardContent className="flex flex-col items-center justify-center p-4">
              <div className="text-3xl font-bold text-blue-600">{isLoading ? "-" : stats.total}</div>
              <div className="text-sm text-gray-500">Total Reports</div>
            </CardContent>
          </Card>

          <Card className={`rounded-xl border-none bg-white shadow-md ${isLoading ? "animate-pulse" : ""}`}>
            <CardContent className="flex flex-col items-center justify-center p-4">
              <div className="text-3xl font-bold text-yellow-600">{isLoading ? "-" : stats.unresolved}</div>
              <div className="text-sm text-gray-500">Unresolved</div>
            </CardContent>
          </Card>

          <Card
            className={`rounded-xl border-none bg-white shadow-md ${isLoading ? "animate-pulse" : ""} ${newUrgentReport ? "animate-bounce bg-red-50" : ""}`}
          >
            <CardContent className="flex items-center gap-3 p-4">
              <div className={`rounded-full ${newUrgentReport ? "bg-red-200" : "bg-red-100"} p-2 text-red-600`}>
                <AlertTriangle className={`h-6 w-6 ${newUrgentReport ? "animate-pulse" : ""}`} />
              </div>
              <div>
                <div className="text-lg font-semibold text-red-600">
                  {isLoading ? "-" : newUrgentReport ? stats.urgent + 1 : stats.urgent}
                </div>
                <div className="text-xs text-gray-500">Urgent Issues</div>
              </div>
            </CardContent>
          </Card>

          <Card className={`rounded-xl border-none bg-white shadow-md ${isLoading ? "animate-pulse" : ""}`}>
            <CardContent className="flex items-center gap-3 p-4">
              <div className="rounded-full bg-green-100 p-2 text-green-600">
                <TrendingUp className="h-6 w-6" />
              </div>
              <div>
                <div className="text-lg font-semibold text-green-600">{isLoading ? "-" : stats.trend}%</div>
                <div className="text-xs text-gray-500">Resolution Rate</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Urgent Reports Section */}
        {newUrgentReport && (
          <Card className="mb-6 rounded-xl border-none border-red-300 bg-red-50 shadow-md">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center gap-2 text-lg text-red-700">
                <BellRing className="h-5 w-5 animate-pulse" />
                High Urgency Reports
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                {
                  id: 104,
                  description: "NEW: Physical altercation reported in dormitory",
                  category: "Harassment",
                  time: "Just now",
                },
                ...urgentReports,
              ].map((report) => (
                <div
                  key={report.id}
                  className={`flex items-center justify-between rounded-lg border-l-4 ${report.time === "Just now" ? "border-l-red-500 bg-white" : "border-l-red-300 bg-white/80"} p-3 shadow-sm`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-sm font-medium ${report.time === "Just now" ? "text-red-600" : "text-gray-900"}`}
                      >
                        {report.description}
                      </span>
                      {report.time === "Just now" && (
                        <span className="rounded-full bg-red-100 px-2 py-0.5 text-xs font-medium text-red-800">
                          NEW
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-gray-500">{report.category}</span>
                      <span className="text-xs text-gray-400">•</span>
                      <span className="text-xs text-gray-500">{report.time}</span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    className="bg-red-600 hover:bg-red-700"
                    onClick={() => router.push("/admin/reports")}
                  >
                    View
                  </Button>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Quick Category Overview */}
        <Card className="mb-6 rounded-xl border-none shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Report Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <div className="grid gap-4">
          <Button
            onClick={() => router.push("/admin/reports")}
            className="flex h-auto items-center justify-start gap-3 rounded-xl bg-blue-600 p-4 text-left text-white hover:bg-blue-700"
          >
            <div className="rounded-full bg-blue-500 p-2">
              <ClipboardList className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-semibold">View All Reports</div>
              <div className="text-sm opacity-90">Manage and respond to reports</div>
            </div>
          </Button>

          <Button
            onClick={() => router.push("/admin/analytics")}
            className="flex h-auto items-center justify-start gap-3 rounded-xl bg-blue-600 p-4 text-left text-white hover:bg-blue-700"
          >
            <div className="rounded-full bg-blue-500 p-2">
              <BarChart2 className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-semibold">Analytics</div>
              <div className="text-sm opacity-90">View report statistics and trends</div>
            </div>
          </Button>

          <Button
            onClick={() => router.push("/admin/settings")}
            className="flex h-auto items-center justify-start gap-3 rounded-xl bg-blue-600 p-4 text-left text-white hover:bg-blue-700"
          >
            <div className="rounded-full bg-blue-500 p-2">
              <Settings className="h-6 w-6" />
            </div>
            <div>
              <div className="text-lg font-semibold">Settings</div>
              <div className="text-sm opacity-90">Manage account and preferences</div>
            </div>
          </Button>
        </div>

        {/* Recent Activity */}
        <Card className="mt-6 rounded-xl border-none shadow-md">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Clock className="h-5 w-5" />
              Recent Activity
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between border-b border-gray-100 pb-2">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-red-500"></div>
                <span className="text-sm">New urgent report submitted</span>
              </div>
              <span className="text-xs text-gray-500">10 min ago</span>
            </div>
            <div className="flex items-center justify-between border-b border-gray-100 pb-2">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-green-500"></div>
                <span className="text-sm">Report #1234 marked as resolved</span>
              </div>
              <span className="text-xs text-gray-500">1 hour ago</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-blue-500"></div>
                <span className="text-sm">New user registered</span>
              </div>
              <span className="text-xs text-gray-500">3 hours ago</span>
            </div>
          </CardContent>
        </Card>
      </main>

      <SafeSpacesNavbar activeTab="home" role="admin" />

      {/* Chatbot */}
      <Chatbot />
    </div>
  )
}
