"use client"

import { useState, useEffect } from "react"
import { SafeSpacesHeader } from "@/components/shared/safe-spaces-header"
import { SafeSpacesNavbar } from "@/components/shared/safe-spaces-navbar"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LineChart,
  Line,
  CartesianGrid,
  Area,
  AreaChart,
} from "recharts"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

// Sample data for demonstration
const categoryData = [
  { name: "Hygiene", value: 15, color: "#0ea5e9" },
  { name: "Harassment", value: 30, color: "#f43f5e" },
  { name: "Safety", value: 20, color: "#f59e0b" },
  { name: "Facilities", value: 25, color: "#10b981" },
  { name: "General", value: 10, color: "#6366f1" },
]

const urgencyData = [
  { name: "Low", value: 40, color: "#10b981" },
  { name: "Medium", value: 35, color: "#f59e0b" },
  { name: "High", value: 25, color: "#f43f5e" },
]

const timeData = [
  { name: "Mon", reports: 5, resolved: 3 },
  { name: "Tue", reports: 8, resolved: 5 },
  { name: "Wed", reports: 12, resolved: 7 },
  { name: "Thu", reports: 7, resolved: 4 },
  { name: "Fri", reports: 10, resolved: 6 },
  { name: "Sat", reports: 3, resolved: 2 },
  { name: "Sun", reports: 2, resolved: 1 },
]

const trendData = [
  { name: "Week 1", reports: 15, resolved: 10 },
  { name: "Week 2", reports: 20, resolved: 15 },
  { name: "Week 3", reports: 25, resolved: 18 },
  { name: "Week 4", reports: 18, resolved: 14 },
]

const locationData = [
  { name: "Library", value: 15 },
  { name: "Cafeteria", value: 25 },
  { name: "Dormitory", value: 30 },
  { name: "Classroom", value: 20 },
  { name: "Other", value: 10 },
]

export default function AdminAnalyticsPage() {
  const { toast } = useToast()
  const [timeRange, setTimeRange] = useState("week")
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("category")

  useEffect(() => {
    // Simulate loading data
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Analytics Loaded",
        description: "Showing analytics data for this week.",
      })
    }, 1500)
  }, [toast])

  const handleTimeRangeChange = (value: string) => {
    setTimeRange(value)
    setIsLoading(true)

    // Simulate loading new data
    setTimeout(() => {
      setIsLoading(false)
      toast({
        title: "Time Range Updated",
        description: `Showing data for ${value === "today" ? "today" : value === "week" ? "this week" : "this month"}.`,
      })
    }, 1000)
  }

  return (
    <div className="flex min-h-screen flex-col bg-gradient-to-b from-teal-50 to-blue-50">
      <SafeSpacesHeader showBackButton isAdmin />

      <main className="flex-1 p-4">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Analytics</h1>
            <p className="text-gray-600">Report statistics and trends</p>
          </div>
          <Select value={timeRange} onValueChange={handleTimeRangeChange}>
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="category" className="space-y-4" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="category">Category</TabsTrigger>
            <TabsTrigger value="urgency">Urgency</TabsTrigger>
            <TabsTrigger value="time">Time</TabsTrigger>
            <TabsTrigger value="location">Location</TabsTrigger>
          </TabsList>

          <TabsContent value="category">
            <Card className="rounded-xl border-none shadow-md">
              <CardHeader>
                <CardTitle className="text-lg">Reports by Category</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                {isLoading ? (
                  <div className="flex h-[300px] w-full items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
                  </div>
                ) : (
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={categoryData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        >
                          {categoryData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} reports`, "Count"]} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="urgency">
            <Card className="rounded-xl border-none shadow-md">
              <CardHeader>
                <CardTitle className="text-lg">Reports by Urgency</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-center">
                {isLoading ? (
                  <div className="flex h-[300px] w-full items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
                  </div>
                ) : (
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={urgencyData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`${value} reports`, "Count"]} />
                        <Legend />
                        <Bar dataKey="value" name="Reports">
                          {urgencyData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="time">
            <Card className="rounded-xl border-none shadow-md">
              <CardHeader>
                <CardTitle className="text-lg">Reports Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex h-[300px] w-full items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
                  </div>
                ) : (
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={timeRange === "month" ? trendData : timeData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="reports" stroke="#0ea5e9" name="Reports Submitted" />
                        <Line type="monotone" dataKey="resolved" stroke="#10b981" name="Reports Resolved" />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="location">
            <Card className="rounded-xl border-none shadow-md">
              <CardHeader>
                <CardTitle className="text-lg">Reports by Location</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex h-[300px] w-full items-center justify-center">
                    <Loader2 className="h-8 w-8 animate-spin text-teal-600" />
                  </div>
                ) : (
                  <div className="h-[300px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={locationData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => [`${value} reports`, "Count"]} />
                        <Area type="monotone" dataKey="value" fill="#0ea5e9" stroke="#0ea5e9" name="Reports" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Summary Card */}
        <Card className="mt-6 rounded-xl border-none shadow-md">
          <CardHeader>
            <CardTitle className="text-lg">Key Insights</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                <div className="h-4 w-3/4 animate-pulse rounded bg-gray-200"></div>
                <div className="h-4 w-full animate-pulse rounded bg-gray-200"></div>
                <div className="h-4 w-5/6 animate-pulse rounded bg-gray-200"></div>
              </div>
            ) : (
              <div className="space-y-2 text-sm">
                <p>
                  • <strong>Harassment reports</strong> make up the largest category at 30%.
                </p>
                <p>
                  • <strong>High urgency</strong> reports have increased by 15% compared to last {timeRange}.
                </p>
                <p>
                  • <strong>Resolution rate</strong> is currently at 65%, which is 5% higher than last {timeRange}.
                </p>
                <p>
                  • <strong>Dormitory</strong> is the location with the most reports (30%).
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </main>

      <SafeSpacesNavbar activeTab="analytics" role="admin" />
    </div>
  )
}
